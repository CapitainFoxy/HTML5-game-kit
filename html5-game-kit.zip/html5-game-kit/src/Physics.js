export default class Physics {
    static applyGravity(entity, gravity = 0.98) {
      entity.velocity.y += gravity;
    }
  
    static applyFriction(entity, friction = 0.9) {
      entity.velocity.x *= friction;
      entity.velocity.y *= friction;
    }
  }
  