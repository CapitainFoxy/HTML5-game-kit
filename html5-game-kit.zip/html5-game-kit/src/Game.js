export default class Game {
    constructor(width, height) {
      this.width = width;
      this.height = height;
      this.entities = [];
    }
  
    addEntity(entity) {
      this.entities.push(entity);
    }
  
    update() {
      this.entities.forEach(entity => entity.update());
    }
  
    render(context) {
      context.clearRect(0, 0, this.width, this.height);
      this.entities.forEach(entity => entity.render(context));
    }
  }
  